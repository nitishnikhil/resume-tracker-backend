require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());

// ✅ Serve frontend FIRST
app.use(express.static(path.join(__dirname, "public")));

// ✅ API routes
app.use("/api/resumes", require("./src/routes/resumes"));

// ✅ Health / backend test route (NOT root)
app.get("/health", (req, res) => {
  res.json({
    status: "success",
    message: "Backend is working!",
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`✅ Server running on port ${PORT}`);
});
